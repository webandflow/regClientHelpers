<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '529fd0ca705fba47b2959913332c39f7',
      'native_key' => 'regclienthelpers',
      'filename' => 'modNamespace/b617588f748fe30e3c27f307c0c8b5ab.vehicle',
      'namespace' => 'regclienthelpers',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1368da01c51de7bef81d5ce7c79442f4',
      'native_key' => 1,
      'filename' => 'modCategory/a64a53c3242184467ebcf97b6d53c22c.vehicle',
      'namespace' => 'regclienthelpers',
    ),
  ),
);